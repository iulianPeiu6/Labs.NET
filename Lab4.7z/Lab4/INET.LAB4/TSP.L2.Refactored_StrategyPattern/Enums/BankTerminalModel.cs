﻿namespace INET.Lab4.Enums
{
    public enum BankTerminalModel
    {
        Brp,
        Dcp
    }
}