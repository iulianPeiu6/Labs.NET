namespace INET.Lab4.Enums
{
    public enum DeviceModel
    {
        CoinDispenserCube4,
        CoinDispsenerSch2,
        CoinAccepterNri,
        BillAccepterCashCode,
        BillDispenserEcdm
    }
}