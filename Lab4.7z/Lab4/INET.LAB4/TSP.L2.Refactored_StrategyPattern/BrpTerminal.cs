﻿using INET.Lab4.FirstAttempt_StrategyPattern.Interfaces;

namespace INET.Lab4.Models
{
    public class BrpTerminal : IBankTerminal
    {
    }
}