﻿namespace INET.Lab4.Interfaces
{
    public interface IBankTerminal
    {
    }
}