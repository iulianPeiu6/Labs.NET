﻿using INET.Lab4.Abstracts;

namespace INET.Lab4
{
    public class OnlineProcessor : PaymentProcessor
    {
        protected override void WithdrawMoney() { }

        protected override void CalculateBonus() { }

        protected override void SendGreetings() { }
    }
}
