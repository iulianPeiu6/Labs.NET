﻿namespace INET.Lab4.Models
{
    public interface IBankTerminal
    {
    }
}