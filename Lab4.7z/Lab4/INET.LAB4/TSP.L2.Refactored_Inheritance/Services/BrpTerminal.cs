﻿namespace INET.Lab4.Models
{
    public class BrpTerminal : IBankTerminal
    {
    }
}